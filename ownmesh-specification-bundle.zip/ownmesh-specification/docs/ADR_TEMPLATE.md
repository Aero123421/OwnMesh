# ADR-NNNN: Title

- **Status:** Proposed | Accepted | Superseded | Rejected
- **Date:** YYYY-MM-DD
- **Owners:**
- **Related issues/PRs:**
- **Supersedes:**
- **Superseded by:**

## Context

What problem or constraint requires a durable design decision? Include affected platforms, security boundaries, protocols, compatibility, and user experience.

## Decision

State the chosen design precisely. Use normative language for requirements that future implementations must preserve.

## Alternatives considered

### Alternative A

Benefits, drawbacks, migration cost, security implications.

### Alternative B

Benefits, drawbacks, migration cost, security implications.

## Consequences

### Positive

- ...

### Negative / trade-offs

- ...

### Security and privacy impact

- Trust boundaries changed:
- New credentials/data flows:
- New attack surface:
- Required mitigations/tests:

### Compatibility and migration

- Protocol/schema version impact:
- Rollback plan:
- Mixed-version behavior:

## Verification

List concrete tests, metrics, or evidence proving the decision is implemented correctly.

## Follow-up work

- [ ] ...
